import './App.css';
import ExerciseApp from "./components/ExerciseApp"

function App() {
  return (
    <div className="App">
       <ExerciseApp ></ExerciseApp>
    </div>
  );
}

export default App;
