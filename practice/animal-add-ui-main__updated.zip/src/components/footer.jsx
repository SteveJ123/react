import React from 'react'

const Footer = () => {
  return (
    <footer>
      <div className="container">
        <p>
           Instagram ⚈ Privacy Policy ⚈ Terms and Conditions
        </p>
    </div>
  </footer>
    );
};

export default Footer