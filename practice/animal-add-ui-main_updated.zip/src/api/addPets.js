import  React, {useState} from "react";
// import { Button, Typography, Container, Box } from "@mui/material";
// import { createTheme, ThemeProvider } from "@mui/material/styles";
import AppNavBar from "../components/top-navbar";
import Form from "../api/form";
// import Paper from '@mui/material/Paper';
// import { styled } from '@mui/material/styles';
import Cooper from "../images/Cooper.jpg";
import "../css/images.css";


export default function AddPets() {
   
    return (
        <>
            <AppNavBar />
            <Form />
         
           
        </>
    );
}
